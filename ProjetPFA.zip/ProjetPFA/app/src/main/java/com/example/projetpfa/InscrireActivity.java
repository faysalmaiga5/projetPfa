package com.example.projetpfa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.RequestQueue;
import com.example.projetpfa.pfarequete.PfaRequete;

public class InscrireActivity extends AppCompatActivity {

    private Button btn_env;
    private EditText et_pseudo,et_email,et_password,et_password2;
    private RequestQueue queue;
    private PfaRequete requete;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscrire);

        btn_env =findViewById(R.id.btn_send);
        et_pseudo = findViewById(R.id.et_pseudo);
        et_email = findViewById(R.id.et_email);
        et_password = findViewById(R.id.et_password);
        et_password2 = findViewById(R.id.et_password2);

        queue = VolleySingleton.getInstance(this).getRequestQueue();
        requete = new PfaRequete(this,queue);

        btn_env.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pseudo = et_pseudo.getText().toString().trim();
                String email = et_email.getText().toString().trim();
                String password = et_password.getText().toString().trim();
                String password2 = et_password2.getText().toString().trim();
                requete.register(pseudo,email,password,password2);
            }
        });

    }
}
